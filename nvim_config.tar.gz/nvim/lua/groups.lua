vim.api.nvim_create_autocmd('TextYankPost', {
    desc = 'Highlight when yanking (copying) text',
    group = vim.api.nvim_create_augroup('kickstart-highlight-yank', { clear = true }),
    callback = function()
        vim.hl.on_yank()
    end,
})

vim.opt.showtabline = 1

vim.api.nvim_create_autocmd({ "TabNew", "TabClosed", "TabEnter" }, {
  callback = function()
    local count = #vim.api.nvim_list_tabpages()
    vim.opt.showtabline = (count > 1) and 2 or 1
  end,
})

vim.opt.showtabline = 1
-- On startup after all UI is ready
vim.api.nvim_create_autocmd("VimEnter", {
  callback = function()
    local tab_count = #vim.api.nvim_list_tabpages()
    vim.opt.showtabline = (tab_count > 1) and 2 or 0
  end,
})
