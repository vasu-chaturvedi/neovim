return {
    {
        'rmagatti/auto-session',
        config = function()
            require('auto-session').setup {
                log_level = 'error',
                auto_session_suppress_dirs = { '~/', '/' },
                auto_restore_enabled = true,
                auto_save_enabled = true,
            }
            -- Save session on every write
            vim.api.nvim_create_autocmd('BufWritePost', {
                callback = function()
                    vim.cmd('SessionSave')
                end,
            })
        end,
    },
}
