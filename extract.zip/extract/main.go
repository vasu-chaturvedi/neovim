package main

import (
	"context"
	"database/sql"
	"flag"
	"fmt"
	"log"
	"path/filepath"
	"sync"
	"time"

	_ "github.com/godror/godror"
)

func main() {
	mainConfigPath := flag.String("main-config", "config.json", "Path to main config JSON file")
	extractionConfigPath := flag.String("extraction-config", "extraction_config.json", "Path to extraction config JSON file")
	flag.Parse()

	appCfg, err := loadMainConfig(*mainConfigPath)
	if err != nil {
		log.Fatalf("Failed to load main config: %v", err)
	}

	runCfg, err := loadExtractionConfig(*extractionConfigPath)
	if err != nil {
		log.Fatalf("Failed to load extraction config: %v", err)
	}

	fmt.Println("extractionCfg", runCfg)

	connString := fmt.Sprintf(`user="%s" password="%s" connectString="%s:%d/%s"`,
		appCfg.DBUser, appCfg.DBPassword, appCfg.DBHost, appCfg.DBPort, appCfg.DBSid)

	fmt.Println("Connection String", connString)

	procCount := len(runCfg.Procedures)

	db, err := sql.Open("godror", connString)
	if err != nil {
		log.Fatalf("Failed to connect to DB: %v", err)
	}
	defer db.Close()

	db.SetMaxOpenConns(appCfg.Concurrency * procCount)
	db.SetMaxIdleConns(appCfg.Concurrency * procCount)
	db.SetConnMaxLifetime(30 * time.Minute)

	fmt.Println("Sol List", appCfg.SolFilePath)

	sols, err := readSols(appCfg.SolFilePath)
	if err != nil {
		log.Fatalf("Failed to read SOL IDs: %v", err)
	}

	fmt.Println("Sol List ", sols)

	// Channels & mutexes for logging
	procLogCh := make(chan ProcLog, 1000)
	var summaryMu sync.Mutex
	procSummary := make(map[string]ProcSummary)

	// Start log writer goroutine
	go writeProcLogs(filepath.Join(appCfg.LogFilePath, "procedure_calls.csv"), procLogCh)

	// Semaphore channel to limit concurrency of SOL processing
	sem := make(chan struct{}, appCfg.Concurrency)
	var wg sync.WaitGroup

	ctx := context.Background()

	for _, sol := range sols {
		wg.Add(1)
		sem <- struct{}{}
		go func(solID string) {
			defer wg.Done()
			defer func() { <-sem }()
			runProceduresForSol(ctx, db, solID, &runCfg, procLogCh, &summaryMu, procSummary)
		}(sol)
	}

	wg.Wait()
	close(procLogCh)

	// Write procedure summary log CSV
	writeProcedureSummary(filepath.Join(appCfg.LogFilePath, "procedure_summary.csv"), procSummary)

	// Consolidate spool files per procedure
	err = consolidateSpoolFiles(&runCfg)
	if err != nil {
		log.Printf("Error consolidating spool files: %v", err)
	}

	log.Println("All done!")
}
