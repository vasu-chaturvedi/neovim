package main

import (
	"context"
	"database/sql"
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

func runProceduresForSol(ctx context.Context, db *sql.DB, solID string, procConfig *ExtractionConfig, logCh chan<- ProcLog, mu *sync.Mutex, summary map[string]ProcSummary) {
	for _, proc := range procConfig.Procedures {
		start := time.Now()
		err := callProcedure(ctx, db, procConfig.PackageName, proc, solID)
		end := time.Now()

		plog := ProcLog{
			SolID:         solID,
			Procedure:     proc,
			StartTime:     start,
			EndTime:       end,
			ExecutionTime: end.Sub(start),
		}
		if err != nil {
			plog.Status = "FAIL"
			plog.ErrorDetails = err.Error()
		} else {
			plog.Status = "SUCCESS"
		}
		logCh <- plog

		mu.Lock()
		s, exists := summary[proc]
		if !exists {
			s = ProcSummary{
				Procedure: proc,
				StartTime: start,
				EndTime:   end,
				Status:    plog.Status,
			}
		} else {
			if start.Before(s.StartTime) {
				s.StartTime = start
			}
			if end.After(s.EndTime) {
				s.EndTime = end
			}
			// Once failed always fail
			if s.Status != "FAIL" && plog.Status == "FAIL" {
				s.Status = "FAIL"
			}
		}
		summary[proc] = s
		mu.Unlock()

		if err == nil {
			// On success run extraction SQL and spool output
			err2 := runExtractionSQL(ctx, db, procConfig, proc, solID)
			if err2 != nil {
				log.Printf("Extraction SQL failed for %s: %v", proc, err2)
			}
		}
	}
}

// Call stored procedure with solID parameter
func callProcedure(ctx context.Context, db *sql.DB, pkgName, procName, solID string) error {
	query := fmt.Sprintf("BEGIN %s.%s(:1); END;", pkgName, procName)
	_, err := db.ExecContext(ctx, query, solID)
	return err
}

// Run the extraction SQL file for a procedure and generate spool output
func runExtractionSQL(db *sql.DB, procConfig *ExtractionConfig, proc, solID string) error {
	sqlFile := filepath.Join(procConfig.ExtractionSQLPath, proc+".sql")

	// Read the SQL query from file (should be just the SELECT query)
	content, err := os.ReadFile(sqlFile)
	if err != nil {
		return fmt.Errorf("failed to read SQL file: %w", err)
	}
	query := string(content)

	// Execute the query with solID as bind variable
	rows, err := db.Query(query, solID)
	if err != nil {
		return fmt.Errorf("query execution failed for proc %s with SOL ID %s: %w", proc, solID, err)
	}
	defer rows.Close()

	spoolFile := filepath.Join(procConfig.SpoolOutputPath, proc+"_"+solID+"_"+time.Now().Format("20060102_150405")+".txt")
	fSpool, err := os.Create(spoolFile)
	if err != nil {
		return fmt.Errorf("failed to create spool file: %w", err)
	}
	defer fSpool.Close()

	// Get column count for dynamic scanning
	cols, err := rows.Columns()
	if err != nil {
		return fmt.Errorf("failed to get columns: %w", err)
	}

	vals := make([]interface{}, len(cols))
	valPtrs := make([]interface{}, len(cols))
	for i := range vals {
		valPtrs[i] = &vals[i]
	}

	// Iterate rows and write pipe-delimited values, no headers
	for rows.Next() {
		err := rows.Scan(valPtrs...)
		if err != nil {
			return fmt.Errorf("failed to scan row: %w", err)
		}
		var fields []string
		for _, v := range vals {
			var s string
			if v == nil {
				s = ""
			} else {
				s = fmt.Sprintf("%v", v)
			}
			fields = append(fields, s)
		}
		line := strings.Join(fields, "|") + "\n"
		if _, err := fSpool.WriteString(line); err != nil {
			return fmt.Errorf("failed to write to spool file: %w", err)
		}
	}

	if err = rows.Err(); err != nil {
		return fmt.Errorf("rows iteration error: %w", err)
	}

	return nil
}

// Write detailed procedure call logs to CSV
func writeProcLogs(path string, logCh <-chan ProcLog) {
	file, err := os.Create(path)
	if err != nil {
		log.Fatalf("Failed to create procedure log file: %v", err)
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()

	// Write header
	writer.Write([]string{"SOL_ID", "PROCEDURE", "START_TIME", "END_TIME", "EXECUTION_SECONDS", "STATUS", "ERROR_DETAILS"})

	for plog := range logCh {
		errDetails := plog.ErrorDetails
		if errDetails == "" {
			errDetails = "-"
		}
		record := []string{
			plog.SolID,
			plog.Procedure,
			plog.StartTime.Format(time.RFC3339),
			plog.EndTime.Format(time.RFC3339),
			fmt.Sprintf("%.3f", plog.ExecutionTime.Seconds()),
			plog.Status,
			errDetails,
		}
		writer.Write(record)
	}
}

// Write procedure summary CSV after all executions
func writeProcedureSummary(path string, summary map[string]ProcSummary) {
	file, err := os.Create(path)
	if err != nil {
		log.Printf("Failed to create procedure summary file: %v", err)
		return
	}
	defer file.Close()

	writer := csv.NewWriter(file)
	defer writer.Flush()

	// Header
	writer.Write([]string{"PROCEDURE", "EARLIEST_START_TIME", "LATEST_END_TIME", "STATUS"})

	// Sort procedures alphabetically
	var procs []string
	for p := range summary {
		procs = append(procs, p)
	}
	sort.Strings(procs)

	for _, p := range procs {
		s := summary[p]
		writer.Write([]string{
			p,
			s.StartTime.Format(time.RFC3339),
			s.EndTime.Format(time.RFC3339),
			s.Status,
		})
	}
}

// Consolidate multiple spool files per procedure into one <proc>.txt file
func consolidateSpoolFiles(procConfig *ExtractionConfig) error {
	files, err := os.ReadDir(procConfig.SpoolOutputPath)
	if err != nil {
		return fmt.Errorf("failed to read spool output directory: %w", err)
	}

	// Map procedure name -> list of spool files
	spoolFilesMap := make(map[string][]string)
	for _, f := range files {
		if f.IsDir() {
			continue
		}
		name := f.Name()
		for _, proc := range procConfig.Procedures {
			if strings.HasPrefix(name, proc+"_") && (strings.HasSuffix(name, ".txt") || strings.HasSuffix(name, ".spool")) {
				spoolFilesMap[proc] = append(spoolFilesMap[proc], filepath.Join(procConfig.SpoolOutputPath, name))
			}
		}
	}

	for proc, files := range spoolFilesMap {
		outFile := filepath.Join(procConfig.SpoolOutputPath, proc+".txt")
		fOut, err := os.Create(outFile)
		if err != nil {
			log.Printf("Failed to create consolidated file for %s: %v", proc, err)
			continue
		}

		var totalBytes int64
		for i, fpath := range files {
			fIn, err := os.Open(fpath)
			if err != nil {
				log.Printf("Failed to open spool file %s: %v", fpath, err)
				continue
			}

			n, err := io.Copy(fOut, fIn)
			fIn.Close()
			if err != nil {
				log.Printf("Error copying spool file %s: %v", fpath, err)
				continue
			}
			totalBytes += n

			// Delete the file after successful copy
			err = os.Remove(fpath)
			if err != nil {
				log.Printf("Failed to delete spool file %s after consolidation: %v", fpath, err)
			} else {
				log.Printf("Deleted spool file %s after consolidation", fpath)
			}

			// Add newline between files except after last one
			if i < len(files)-1 {
				if _, err := fOut.Write([]byte("\n")); err != nil {
					log.Printf("Failed to write newline after file %s: %v", fpath, err)
				}
			}
		}

		if err := fOut.Close(); err != nil {
			log.Printf("Failed to close consolidated file %s: %v", outFile, err)
		}

		log.Printf("Consolidated %d files for %s, total bytes: %d", len(files), proc, totalBytes)
	}

	return nil
}
