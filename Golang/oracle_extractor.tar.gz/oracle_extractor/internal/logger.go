package main

import (
	"log"
	"os"
	"path/filepath"
	"time"
)

func SetupLogging(logFolder string) error {
	if _, err := os.Stat(logFolder); os.IsNotExist(err) {
		err := os.MkdirAll(logFolder, 0755)
		if err != nil {
			return err
		}
	}
	logFile := filepath.Join(logFolder, "execution.log")
	f, err := os.OpenFile(logFile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	log.SetOutput(f)
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)
	return nil
}

func logInfo(msg string) {
	log.Printf("[INFO] %s", msg)
}

func logError(msg string) {
	log.Printf("[ERROR] %s", msg)
}
