package main

import (
	"database/sql"
	"log"
	"sync"
)

type Stats struct {
	Success int
	Failure int
}

func ExecuteProcedureParallel(db *sql.DB, packageName, procName string, solIDs []string, maxParallel int) Stats {
	var wg sync.WaitGroup
	sem := make(chan struct{}, maxParallel)
	stats := Stats{}

	mu := &sync.Mutex{}

	for _, solID := range solIDs {
		wg.Add(1)
		go func(s string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			err := ExecuteProcedure(db, packageName, procName, s)
			mu.Lock()
			if err != nil {
				log.Printf("Procedure %s.%s failed for SOL %s: %v", packageName, procName, s, err)
				stats.Failure++
			} else {
				stats.Success++
			}
			mu.Unlock()
		}(solID)
	}
	wg.Wait()
	return stats
}
