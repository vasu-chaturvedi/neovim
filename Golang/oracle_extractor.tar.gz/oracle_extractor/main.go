package main

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	_ "github.com/godror/godror"
)

func main() {
	// Load config files and decrypted password
	appCfg, err := LoadAppConfig("config/app_config.yaml")
	if err != nil {
		log.Fatalf("Error loading app config: %v", err)
	}
	procCfg, err := LoadProcConfig("config/procedures.yaml")
	if err != nil {
		log.Fatalf("Error loading procedures config: %v", err)
	}
	password, err := LoadDecryptedPassword(appCfg.DB.AESKeyFile, appCfg.DB.PasswordFile)
	if err != nil {
		log.Fatalf("Error decrypting password: %v", err)
	}

	// Connect to DB
	dsn := fmt.Sprintf("%s/%s@%s", appCfg.DB.Username, password, appCfg.DB.DSN)
	db, err := sql.Open("godror", dsn)
	if err != nil {
		log.Fatalf("Failed to open DB connection: %v", err)
	}
	defer db.Close()

	// Setup logging
	err = SetupLogging(appCfg.Execution.LogFolder)
	if err != nil {
		log.Fatalf("Failed to setup logging: %v", err)
	}

	log.Printf("Starting extraction utility")

	// Read SOL IDs
	solIDs, err := ReadSolIDs("sol_ids.txt")
	if err != nil {
		log.Fatalf("Error reading SOL IDs: %v", err)
	}

	for _, procGroup := range procCfg.Procedures {
		for _, fn := range procGroup.Functions {
			log.Printf("Starting procedure %s.%s", procGroup.Package, fn)
			start := time.Now()

			stats := ExecuteProcedureParallel(db, procGroup.Package, fn, solIDs, appCfg.Execution.MaxParallel)

			duration := time.Since(start)
			log.Printf("Completed procedure %s.%s: Success: %d, Failures: %d, Duration: %v", procGroup.Package, fn, stats.Success, stats.Failure, duration)
		}
	}

	log.Printf("Extraction utility completed")
}
