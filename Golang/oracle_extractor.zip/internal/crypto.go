package main

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"io"
	"os"
)

func EncryptGCM(plaintext, key string) (string, error) {
	block, err := aes.NewCipher([]byte(key))
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, aesGCM.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return "", err
	}
	ciphertext := aesGCM.Seal(nonce, nonce, []byte(plaintext), nil)
	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

func DecryptGCM(ciphertextBase64, key string) (string, error) {
	data, err := base64.StdEncoding.DecodeString(ciphertextBase64)
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher([]byte(key))
	if err != nil {
		return "", err
	}
	aesGCM, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonceSize := aesGCM.NonceSize()
	nonce, ciphertext := data[:nonceSize], data[nonceSize:]
	plaintext, err := aesGCM.Open(nil, nonce, ciphertext, nil)
	if err != nil {
		return "", err
	}
	return string(plaintext), nil
}

func LoadDecryptedPassword(aesKeyFile, encPasswordFile string) (string, error) {
	key, err := os.ReadFile(aesKeyFile)
	if err != nil {
		return "", err
	}
	encPass, err := os.ReadFile(encPasswordFile)
	if err != nil {
		return "", err
	}
	return DecryptGCM(string(encPass), string(key))
}

func EncryptPasswordCLI() {
	if len(os.Args) < 4 {
		fmt.Println("Usage: go run crypto.go encrypt <password> <aes_key_file>")
		return
	}
	mode := os.Args[1]
	password := os.Args[2]
	keyFile := os.Args[3]

	key, err := os.ReadFile(keyFile)
	if err != nil {
		fmt.Printf("Error reading AES key file: %v
", err)
		return
	}

	if mode == "encrypt" {
		encrypted, err := EncryptGCM(password, string(key))
		if err != nil {
			fmt.Printf("Encryption error: %v
", err)
			return
		}
		fmt.Println(encrypted)
	} else {
		fmt.Println("Unknown mode. Use 'encrypt'")
	}
}
