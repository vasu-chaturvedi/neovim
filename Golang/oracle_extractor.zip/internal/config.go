package main

import (
	"os"
	"strings"

	"gopkg.in/yaml.v2"
)

type AppConfig struct {
	DB struct {
		Username     string `yaml:"username"`
		DSN          string `yaml:"dsn"`
		AESKeyFile   string `yaml:"aes_key_file"`
		PasswordFile string `yaml:"password_file"`
	} `yaml:"db"`

	Execution struct {
		MaxParallel int    `yaml:"max_parallel"`
		LogFolder   string `yaml:"log_folder"`
	} `yaml:"execution"`
}

type ProcConfig struct {
	Procedures []struct {
		Package   string   `yaml:"package"`
		Functions []string `yaml:"functions"`
	} `yaml:"procedures"`
}

func LoadAppConfig(path string) (*AppConfig, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var cfg AppConfig
	err = yaml.Unmarshal(data, &cfg)
	return &cfg, err
}

func LoadProcConfig(path string) (*ProcConfig, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var cfg ProcConfig
	err = yaml.Unmarshal(data, &cfg)
	return &cfg, err
}

func ReadSolIDs(path string) ([]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	lines := strings.Split(string(data), "\n")
	var solIDs []string
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if line != "" {
			solIDs = append(solIDs, line)
		}
	}
	return solIDs, nil
}
