package main

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/godror/godror"
)

func ConnectToDB(dsn string) (*sql.DB, error) {
	db, err := sql.Open("godror", dsn)
	if err != nil {
		return nil, err
	}
	err = db.Ping()
	if err != nil {
		return nil, err
	}
	return db, nil
}

// Execute one stored procedure with solID
func ExecuteProcedure(db *sql.DB, packageName, procName, solID string) error {
	query := fmt.Sprintf("BEGIN %s.%s(:1); END;", packageName, procName)
	_, err := db.Exec(query, solID)
	return err
}
