fn foo() -> i32 {
    1
}

fn foo(
    x: i32,
    y: i32
) -> i32 {
    x + y
}
