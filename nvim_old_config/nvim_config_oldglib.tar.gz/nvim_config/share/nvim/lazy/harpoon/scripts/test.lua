local a = {}
a[3] = "foo"
print(#a)
