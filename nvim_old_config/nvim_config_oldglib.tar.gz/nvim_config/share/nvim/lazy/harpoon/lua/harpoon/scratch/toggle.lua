local harpoon = require("harpoon")

harpoon.ui:toggle_quick_menu(harpoon:list())
