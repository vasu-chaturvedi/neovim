package main

const (
	ExampleOne = iota
	ExampleTwo
	ExampleThree
)
