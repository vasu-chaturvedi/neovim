def indent_brackets
  {
    {}
  }
end
