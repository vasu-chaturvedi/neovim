my_variable =
    1 + 2 - 3 *
    4 / 5 %
    6 + (
        1 + 2 +
        3
    ) +
    7 + 8 +
    9

function test()
    my_variable =
        1 + 2 - 3 *
        4 / 5 %
        6 + (
            1 + 2 +
            3
        ) +
        7 + 8 +
        9
end
