local M = {}

function M.on_destroy() end

return M
