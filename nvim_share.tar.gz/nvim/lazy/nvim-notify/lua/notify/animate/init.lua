local M = {}

M.spring = require("notify.animate.spring")

return M
