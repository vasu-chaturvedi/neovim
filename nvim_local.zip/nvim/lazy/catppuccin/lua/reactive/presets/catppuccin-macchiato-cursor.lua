local palette = require("catppuccin.palettes").get_palette "macchiato"
local presets = require "catppuccin.utils.reactive"

return presets.cursor("catppuccin-macchiato-cursor", palette)
