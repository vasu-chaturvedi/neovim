local palette = require("catppuccin.palettes").get_palette "frappe"
local presets = require "catppuccin.utils.reactive"

return presets.cursor("catppuccin-frappe-cursor", palette)
