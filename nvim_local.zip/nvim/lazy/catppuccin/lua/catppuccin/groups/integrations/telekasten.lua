local M = {}

function M.get()
	return {
		tkLink = { fg = C.blue },
		tkBrackets = { fg = C.pink },
		tkTag = { fg = C.sky },
	}
end

return M
