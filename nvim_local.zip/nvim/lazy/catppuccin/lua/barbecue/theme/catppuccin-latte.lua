return require "catppuccin.utils.barbecue" "latte"
