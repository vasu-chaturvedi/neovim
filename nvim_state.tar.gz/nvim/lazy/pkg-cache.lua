return {pkgs={{spec=function()
return {
  {
    'saghen/blink.compat',
    lazy = true,
  },
}

end,name="blink.compat",file="lazy.lua",dir="/home/vasuc/nvim_config/share/nvim/lazy/blink.compat",source="lazy",},{spec=function()
return {
  -- nui.nvim can be lazy loaded
  { "MunifTanjim/nui.nvim", lazy = true },
  {
    "folke/noice.nvim",
  },
}

end,name="noice.nvim",file="lazy.lua",dir="/home/vasuc/nvim_config/share/nvim/lazy/noice.nvim",source="lazy",},{spec={"nvim-lua/plenary.nvim",lazy=true,},name="plenary.nvim",file="community",dir="/home/vasuc/nvim_config/share/nvim/lazy/plenary.nvim",source="lazy",},{spec={"telescope.nvim",build=false,specs={{"nvim-lua/plenary.nvim",lazy=true,},},},name="telescope.nvim",file="telescope.nvim-scm-1.rockspec",dir="/home/vasuc/nvim_config/share/nvim/lazy/telescope.nvim",source="rockspec",},},version=12,}