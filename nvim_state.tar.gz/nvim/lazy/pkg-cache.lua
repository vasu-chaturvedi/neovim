return {pkgs={{spec=function()
return {
  {
    'saghen/blink.compat',
    lazy = true,
  },
}

end,name="blink.compat",dir="/home/vasuc/nvim_config/share/nvim/lazy/blink.compat",file="lazy.lua",source="lazy",},{spec=function()
return {
  -- nui.nvim can be lazy loaded
  { "MunifTanjim/nui.nvim", lazy = true },
  {
    "folke/noice.nvim",
  },
}

end,name="noice.nvim",dir="/home/vasuc/nvim_config/share/nvim/lazy/noice.nvim",file="lazy.lua",source="lazy",},{spec={"nvim-lua/plenary.nvim",lazy=true,},name="plenary.nvim",dir="/home/vasuc/nvim_config/share/nvim/lazy/plenary.nvim",file="community",source="lazy",},{spec={"telescope.nvim",build=false,specs={{"nvim-lua/plenary.nvim",lazy=true,},},},name="telescope.nvim",dir="/home/vasuc/nvim_config/share/nvim/lazy/telescope.nvim",file="telescope.nvim-scm-1.rockspec",source="rockspec",},},version=12,}