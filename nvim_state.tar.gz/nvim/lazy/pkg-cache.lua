return {version=12,pkgs={{source="lazy",file="lazy.lua",spec=function()
return {
  {
    'saghen/blink.compat',
    lazy = true,
  },
}

end,dir="/home/vasuc/nvim_config/share/nvim/lazy/blink.compat",name="blink.compat",},{source="lazy",file="lazy.lua",spec=function()
return {
  -- nui.nvim can be lazy loaded
  { "MunifTanjim/nui.nvim", lazy = true },
  {
    "folke/noice.nvim",
  },
}

end,dir="/home/vasuc/nvim_config/share/nvim/lazy/noice.nvim",name="noice.nvim",},{source="lazy",file="community",spec={"nvim-lua/plenary.nvim",lazy=true,},dir="/home/vasuc/nvim_config/share/nvim/lazy/plenary.nvim",name="plenary.nvim",},{source="rockspec",file="telescope.nvim-scm-1.rockspec",spec={"telescope.nvim",build=false,specs={{"nvim-lua/plenary.nvim",lazy=true,},},},dir="/home/vasuc/nvim_config/share/nvim/lazy/telescope.nvim",name="telescope.nvim",},},}