-- plugin
return {
    "nvim-lualine/lualine.nvim",
    dependencies = { "nvim-tree/nvim-web-devicons" },
    event = { "VeryLazy" },
    opts = {
        icons_enabled = true,
        options = {
            theme = "auto",
            component_separators = { left = "│", right = "│" },
            disabled_filetypes = { "snacks_dashboard" },
            component_separators = { left = "", right = "" },
            section_separators = { left = "", right = "" },
        },
        sections = {
            lualine_a = {
                "mode",
            },
            lualine_b = {
                {
                    "lsp_status",
                    icon = "",
                    symbols = {
                        spinner = { "⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏" },
                        done = "✓",
                        separator = " ",
                    },
                    ignore_lsp = {},
                },
            },
            lualine_c = {
                {
                    "filename",
                    path = 3,
                    shorting_target = 0,
                },
            },
            lualine_x = {
                "filesize",
            },
            lualine_y = {
                "searchcount",
                "selectioncount",
                "encoding",
                "filetype",
            },
            lualine_z = {

                "progress",
                "location",
            },
        },
        inactive_sections = {
            lualine_a = {},
            lualine_b = {},
            lualine_c = { "filename" },
            lualine_x = { "location" },
            lualine_y = {},
            lualine_z = {},
        },
        tabline = {},
        winbar = {},

        inactive_winbar = {},
        extensions = {},
    },
    config = function(_, opts)
        require("lualine").setup(opts)
        vim.opt.laststatus = 3
    end,
}
